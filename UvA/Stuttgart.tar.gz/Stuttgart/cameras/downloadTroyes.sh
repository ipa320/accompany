

wget -nc http://sbt.science.uva.nl/accompany_Stuttgart/2014-02-09-13-22-31.bag
wget -nc http://sbt.science.uva.nl/accompany_Stuttgart/2014-02-09-13-25-34.bag
wget -nc http://sbt.science.uva.nl/accompany_Stuttgart/2014-02-09-13-26-26.bag
wget -nc http://sbt.science.uva.nl/accompany_Stuttgart/2014-02-09-13-29-47.bag
