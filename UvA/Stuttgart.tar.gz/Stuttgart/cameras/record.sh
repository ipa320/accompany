
rosrun rosbag record --topic /camera_kitchen/image_raw/theora /camera_kitchen/camera_info /camera_sofa/image_raw/theora /camera_sofa/camera_info /tf /humanDetections /trackedHumans /face_recognitions /cam3d/depth_registered/image_raw/compressedDepth /cam3d/depth_registered/camera_info /cam3d/rgb/image_raw/theora /cam3d/rgb/camera_info /map /visualization_marker_array
