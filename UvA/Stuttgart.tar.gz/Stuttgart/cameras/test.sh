
./downloadStuttgart.sh

roslaunch testTracker.launch
